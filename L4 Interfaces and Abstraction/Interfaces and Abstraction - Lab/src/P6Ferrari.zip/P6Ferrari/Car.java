package P6Ferrari;

public interface Car {
    String brakes();
    String gas();
}
